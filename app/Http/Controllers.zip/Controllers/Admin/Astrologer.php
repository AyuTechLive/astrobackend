<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Astrologer extends Controller
{
    public $currentStep = 1;
}
